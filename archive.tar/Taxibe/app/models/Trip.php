<?php

namespace app\models;

class Trip {

    public static function getTripsByDay($db) {
        $stmt = $db->prepare("
            SELECT 
                t.time_depart::DATE AS trip_date, 
                v.registration_number AS vehicle_registration, 
                d.name AS driver_name,
                SUM(t.distance_km) AS total_distance,
                SUM(t.fare_amount) AS total_fare,
                SUM(t.fuel_amount) AS total_fuel
            FROM trips t
            JOIN vehicles v ON t.vehicle_id = v.id
            JOIN drivers d ON t.driver_id = d.id
            GROUP BY t.departure_time::DATE, v.registration_number, d.name
            ORDER BY trip_date DESC
        ");
        $stmt1=$db->prepare("
        SELECT 
    DATE(t.time_depart) AS trip_date,
    v.registration_number AS vehicle,
    d.name AS driver,
    SUM(t.distance_km) AS total_distance_km,
    SUM(t.montant_recette) AS total_recette,
    SUM(t.montant_carburant) AS total_carburant
FROM 
    trips t
JOIN 
    vehicles v ON t.vehicle_id = v.id
JOIN 
    drivers d ON t.driver_id = d.id
GROUP BY 
    DATE(t.time_depart), v.registration_number, d.name
ORDER BY 
    trip_date ASC, vehicle, driver;

        ");
        $stmt1->execute();
        return $stmt1->fetchAll(\PDO::FETCH_ASSOC);
    }

    public static function getProfitByVehicle($db) {
        $stmt = $db->prepare("
            SELECT 
                v.registration_number AS vehicle_registration,
                SUM(t.fare_amount) - SUM(t.fuel_amount) AS net_profit
            FROM trips t
            JOIN vehicles v ON t.vehicle_id = v.id
            GROUP BY v.registration_number
            ORDER BY net_profit DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public static function getProfitByDay($db) {
        $stmt = $db->prepare("
            SELECT 
                t.departure_time::DATE AS trip_date,
                SUM(t.fare_amount) - SUM(t.fuel_amount) AS net_profit
            FROM trips t
            GROUP BY t.departure_time::DATE
            ORDER BY trip_date DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    
    public static function getMostProfitableTrips($db) {
        $stmt = $db->prepare("
            SELECT 
                t.id, 
                t.departure_time::DATE AS trip_date, 
                t.departure_point, 
                t.arrival_point, 
                t.distance_km, 
                t.fare_amount, 
                t.fuel_amount,
                (t.fare_amount - t.fuel_amount) AS net_profit
            FROM trips t
            ORDER BY trip_date DESC, net_profit DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    
  
}
