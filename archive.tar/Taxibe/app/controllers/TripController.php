<?php

namespace app\controllers;

use Flight;
use app\models\Trip;

class TripController {

    protected $app;

    public function __construct($app) {
        $this->app = $app;
    }

    // Liste des trajets par jour avec les informations supplémentaires
    public function getTripsByDay() {
        $db = $this->app->get('db');
        $result = Trip::getTripsByDay($db);
        $this->app->json($result, 200, true, 'utf-8', JSON_PRETTY_PRINT);
    }

    // Total bénéfice par véhicule
    public function getProfitByVehicle() {
        $db = $this->app->get('db');
        $result = Trip::getProfitByVehicle($db);
        $this->app->json($result, 200, true, 'utf-8', JSON_PRETTY_PRINT);
    }

    // Total bénéfice par jour
    public function getProfitByDay() {
        $db = $this->app->get('db');
        $result = Trip::getProfitByDay($db);
        $this->app->json($result, 200, true, 'utf-8', JSON_PRETTY_PRINT);
    }

    // Trajets les plus rentables
    public function getMostProfitableTrips() {
        $db = $this->app->get('db');
        $result = Trip::getMostProfitableTrips($db);
        $this->app->json($result, 200, true, 'utf-8', JSON_PRETTY_PRINT);
    }
}
