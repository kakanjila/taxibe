<?php

use app\controllers\ApiExampleController;
use app\controllers\WelcomeController;
use app\controllers\TripController;
use flight\Engine;
use flight\net\Router;
use Flight;

/**
 * @var Router $router
 * @var Engine $app
 */

// Chargement du contrôleur d'accueil
$Welcome_Controller = new WelcomeController();
$router->get('/', [$Welcome_Controller, 'home']);

// Route hello-world avec un paramètre dynamique
// $router->get('/hello-world/@name', function($name) {
//     echo "<h1>Hello world! Oh hey {$name}!</h1>";
// });

// Routes API pour la gestion des utilisateurs
$router->group('/api', function() use ($router, $app) {
    $Api_Example_Controller = new ApiExampleController($app);

    // Obtenir tous les utilisateurs
    $router->get('/users', [$Api_Example_Controller, 'getUsers']);

    // Obtenir un utilisateur par son ID
    $router->get('/users/@id:[0-9]+', [$Api_Example_Controller, 'getUser']);

    // Mettre à jour un utilisateur par son ID
    $router->post('/users/@id:[0-9]+', [$Api_Example_Controller, 'updateUser']);
});

// Routes pour les trajets
$router->group('/trips', function() {
    // Liste des trajets par jour avec les informations supplémentaires
	
	Flight::route('GET /trips_by_day', function() {
		$controller = new \app\controllers\TripController(Flight::app());
		$controller->getTripsByDay();
	});
	

    // Total bénéfice par véhicule
    Flight::route('GET /profit_by_vehicle', function() {
        $controller = new TripController(Flight::app());
        $controller->getProfitByVehicle();
    });

    // Total bénéfice par jour
    Flight::route('GET /profit_by_day', function() {
        $controller = new TripController(Flight::app());
        $controller->getProfitByDay();
    });

    // Trajets les plus rentables
    Flight::route('GET /most_profitable', function() {
        $controller = new TripController(Flight::app());
        $controller->getMostProfitableTrips();
    });
});

// Fonction pour charger un contrôleur de manière dynamique
function loadController($controllerClass) {
    return new $controllerClass(Flight::app());
}

// Exemple d'utilisation de cette fonction pour charger un contrôleur
Flight::route('GET /dynamic_controller_example', function() {
    $controller = loadController(\app\controllers\TripController::class);
    $controller->getTripsByDay(); // Exécuter la méthode spécifique
});
