<?php

class Database {
    private $host;
    private $dbname;
    private $username;
    private $password;
    private $pdo;

    // Constructeur pour initialiser les informations de connexion
    public function __construct($host, $dbname, $username, $password) {
        $this->host = $host;
        $this->dbname = $dbname;
        $this->username = $username;
        $this->password = $password;
    }

    // Méthode pour établir la connexion PDO
    public function connect() {
        if ($this->pdo === null) {
            try {
                // DSN (Data Source Name) pour MySQL
                $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8";
                
                // Création de la connexion PDO
                $this->pdo = new PDO($dsn, $this->username, $this->password);
                
                // Configurer le mode d'erreur de PDO pour lever des exceptions
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                echo "Connexion réussie à la base de données.";
                
            } catch (PDOException $e) {
                // Gestion des erreurs de connexion
                echo "Erreur de connexion : " . $e->getMessage();
            }
        }
        
        return $this->pdo;
    }

    // Méthode pour fermer la connexion
    public function disconnect() {
        $this->pdo = null;
        echo "Déconnexion de la base de données.";
    }
}

// Exemple d'utilisation de la classe
try {
    // Création d'une instance de la classe Database avec les paramètres de connexion
    $db = new Database('localhost', 'nom_de_la_base', 'utilisateur', 'mot_de_passe');
    
    // Connexion à la base de données
    $pdo = $db->connect();
    
    // Vous pouvez maintenant exécuter des requêtes avec $pdo

    // Déconnexion de la base de données (facultatif)
    $db->disconnect();
} catch (Exception $e) {
    echo "Erreur : " . $e->getMessage();
}
