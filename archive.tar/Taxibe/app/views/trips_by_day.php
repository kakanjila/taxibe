<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des trajets par jour</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h1>Liste des trajets par jour</h1>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Véhicule</th>
                <th>Chauffeur</th>
                <th>Kilomètres effectués</th>
                <th>Montant Recette</th>
                <th>Montant Carburant</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($trips)): ?>
                <?php foreach ($trips as $trip): ?>
                    <tr>
                        <!-- Affichage de la date du trajet -->
                        <td><?php echo htmlspecialchars($trip['trip_date']); ?></td>
                        
                        <!-- Affichage du numéro d'immatriculation du véhicule -->
                        <td><?php echo htmlspecialchars($trip['vehicle_registration']); ?></td>
                        
                        <!-- Affichage du nom du chauffeur -->
                        <td><?php echo htmlspecialchars($trip['driver_name']); ?></td>
                        
                        <!-- Affichage des kilomètres effectués -->
                        <td><?php echo htmlspecialchars($trip['total_distance']); ?> km</td>
                        
                        <!-- Affichage du montant de la recette -->
                        <td><?php echo htmlspecialchars($trip['total_fare']); ?> €</td>
                        
                        <!-- Affichage du montant du carburant -->
                        <td><?php echo htmlspecialchars($trip['total_fuel']); ?> €</td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Aucun trajet trouvé pour cette période</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
