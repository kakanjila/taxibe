CREATE TABLE vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    registration_number VARCHAR(20) NOT NULL,
    model VARCHAR(50),
    status ENUM('active', 'inactive') DEFAULT 'active'
);


CREATE TABLE drivers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(15),
    email VARCHAR(100),
    status ENUM('active', 'inactive') DEFAULT 'active'
);

CREATE TABLE trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    driver_id INT NOT NULL,
    point_depart VARCHAR(100) NOT NULL,
    point_arrivee VARCHAR(100) NOT NULL,
    time_depart DATETIME NOT NULL,
    time_arrivee DATETIME NOT NULL,
    distance_km DECIMAL(5,2) NOT NULL, -- Distance du trajet en kilomètres
    montant_recette DECIMAL(10,2) NOT NULL, -- Montant de la recette
    montant_carburant DECIMAL(10,2) NOT NULL, -- Montant du carburant consommé
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
    FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

INSERT INTO vehicles (registration_number, model, status) VALUES
('3133 TBA', 'Sprinter', 'active'),
('5413 TAC', 'Sprinter', 'inactive'),
('8789 TAH', 'Nissan', 'active'),
('3456 TBE', 'Crafter', 'active'),
('1209 TBH', 'Crafter', 'inactive');

INSERT INTO drivers (name, phone_number, email, status) VALUES
('Bema', '0348765390', 'bema@gmail.com', 'active'),
('Ralom', '0324537707', 'ralom@gmail.com', 'active'),
('Dada', '03476255509', 'dada@gmail.com', 'inactive'),
('Koto', '0331198709', 'koto@gmail.com', 'active'),
('Davida', '0347780092', 'davida@gmail.com', 'inactive');

-- Trajet 1 : véhicule 1 (3133 TBA), chauffeur 1 (Bema)
INSERT INTO trips (vehicle_id, driver_id, point_depart, point_arrivee, time_depart, time_arrivee, distance_km, montant_recette, montant_carburant)
VALUES
(1, 1, 'Andoharanofotsy', 'Ambohibao', '2024-12-01 06:30:00', '2024-12-01 07:15:00', 15.50, 2500.00, 250.00);

-- Trajet 2 : véhicule 3 (8789 TAH), chauffeur 2 (Ralom)
INSERT INTO trips (vehicle_id, driver_id, point_depart, point_arrivee, time_depart, time_arrivee, distance_km, montant_recette, montant_carburant)
VALUES
(3, 2, 'Ambohibao', 'Andoharanofotsy', '2024-12-01 08:00:00', '2024-12-01 08:45:00', 15.50, 2400.00, 240.00);

-- Trajet 3 : véhicule 4 (3456 TBE), chauffeur 4 (Koto)
INSERT INTO trips (vehicle_id, driver_id, point_depart, point_arrivee, time_depart, time_arrivee, distance_km, montant_recette, montant_carburant)
VALUES
(4, 4, 'Antananarivo', 'Ivato', '2024-12-01 09:00:00', '2024-12-01 09:30:00', 12.00, 2200.00, 180.00);

-- Trajet 4 : véhicule 1 (3133 TBA), chauffeur 3 (Dada) - inactif
INSERT INTO trips (vehicle_id, driver_id, point_depart, point_arrivee, time_depart, time_arrivee, distance_km, montant_recette, montant_carburant)
VALUES
(1, 3, 'Ivato', 'Antananarivo', '2024-12-02 10:00:00', '2024-12-02 10:40:00', 13.00, 2300.00, 200.00);

-- Trajet 5 : véhicule 2 (5413 TAC), chauffeur 1 (Bema) - inactif (véhicule inactif)
INSERT INTO trips (vehicle_id, driver_id, point_depart, point_arrivee, time_depart, time_arrivee, distance_km, montant_recette, montant_carburant)
VALUES
(2, 1, 'Ambohibao', 'Andoharanofotsy', '2024-12-02 14:00:00', '2024-12-02 14:30:00', 16.00, 2600.00, 250.00);

-- Trajet 6 : véhicule 5 (1209 TBH), chauffeur 4 (Koto) - inactif (véhicule inactif)
INSERT INTO trips (vehicle_id, driver_id, point_depart, point_arrivee, time_depart, time_arrivee, distance_km, montant_recette, montant_carburant)
VALUES
(5, 4, 'Antananarivo', 'Ivato', '2024-12-02 16:00:00', '2024-12-02 16:30:00', 14.00, 2100.00, 190.00);
